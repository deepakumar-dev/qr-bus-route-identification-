<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<!--<meta http-equiv="content-type" content="text/html; charset=utf-8" />-->
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<style>
                .centered-form {
            text-align: center;
        }

        .centered-form form {
            display: inline-block;
            text-align: left;
        }
    </style>
<body>
<?php
include('topnav.php');
?>
<div id="header" style="background-image: url('images/bus.gif');
  background-position: center;
  background-size: cover;
  overflow: hidden;
  width:1550px;
  height:580px;z-index: -5;">
<?php
include('navbar.php');
?><CENTER>
<div class="centered-form" style="margin-top:80px;width:300px;height:300px;border:2px solid yellow;background-color:#02a69e;">
<h1>User Login</h1>
<form method="post" role="form">
            <div>
                <label for="name"></label>
                <input type="text" name="email" class="form-control" id="email" placeholder="email Id" required>
            <br>
            <div>
                <label for="password"></label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
            </div>
            <br>
            <div>
                <center><input type="submit" class="btn-get-started scrollto" name="submit" value="LOGIN" style="color: black;background-color:#ed5a9f"></center>
            </div></div>
        </form>
    
</div>
</CENTER></div>

  <?php
if(isset($_POST['submit']))
{
$email=$_POST['email'];
$password=$_POST['password'];
$q=mysql_query("select * from userregister where email='$email' and password='$password'")or die(mysql_error());
$n=mysql_num_rows($q);
if($n>0)
{
$r=mysql_fetch_array($q);
$_SESSION['uid']=$id=$r['uid'];
$_SESSION['email']=$email=$r['email'];
echo '<meta http-equiv="refresh" content="0;url=viewqr.php">';
echo "<script type='text/javascript'>alert('successfully login');</script>";
}

else
{
echo "<script type='text/javascript'>alert('You are not authorised user');</script>";
}

}
?>
<?php
include('footer.php');
?>
</body>

</html> 