<?php
error_reporting(0);

include "config.php";
include('include/db.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>BUS ROUTES FOR PUBLIC</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>

<div id="topbar">
<h3></h3>
</div>
<div   id="container">
<div id="header">
<!--<img src="images/logo.jpg"/>-->
<ul>


<li><a href="addlocation.php">addlocation details</a></li>
<li><a href="view.php">view location details</a></li>
<li><a href="view details.php">view user details</a></li>
<li><a href="logout.php">logout</a></li>
</ul>
</div>
<div id="banner" >
<!--<img src="images/mam.jpg"/><br>-->
<div id="container1">


<!-- start: BASIC EXAMPLE -->
 <img src="images/logo.jpg" height="300px" width="380px" STYLE="background-color:lightgreen"/>
						
<center><div class="box-register">
					<form name="registration" id="registration"  method="post">
					
						<fieldset>
							<!--<legend>
								Sign Up
							</legend>-->
							<p>
								<b>Add Bus Routes details:</b>
							</p><br>
							<div class="form-group">
								<input type="text" class="form-control" name="bus" placeholder="Bus number" required>
							</div><br>
							<div class="form-group">
								<input type="text" class="form-control" name="location" placeholder="From location" required>
							</div><br>
							<div class="form-group">
								<input type="text" class="form-control" name="tolocation" placeholder="To location" required>
							</div><br>
							<div class="form-group">
								<input type="text" class="form-control" name="price" placeholder="price" required>
							</div><br>
							<div class="form-group">
								<input type="text" class="form-control" name="time" placeholder="time" required>
							</div><br>
							<div class="form-group">
								<input type="text" class="form-control" name="distance" placeholder="distance" required>
							</div><br>
											<P>Image<input type="file" name="pimage" class="form-control" placeholder="Image" autocomplete="off" required></p><br>
							
							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" id="submit" name="submit">
									Submit <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
						</fieldset>
					</form></center><br><br><br>
						<!-- end: BASIC EXAMPLE -->


<div id="footer">
<ul>
<!--<li><a href="#">Part Time Job</a></li>-->
</ul>
<p> &copy  </p>
</div>
</div>
</div>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$pimage=$_FILES['pimage']['name'];
$bus=mysql_real_escape_string($_POST['bus']);
$location=$_POST['location'];
$tolocation=$_POST['tolocation'];
$time=$_POST['time'];
$price=$_POST['price'];
$distance=$_POST['distance'];
mysql_query("insert into adddetails(bus, location, tolocation,time,price, distance, pimage)
						values('$bus', '$location', '$tolocation','$time', '$price','$distance','$pimage')")or die(mysql_error());
move_uploaded_file($_FILES['pimage']['tmp_name'],"images/$pimage");
echo "<script type='text/javascript'>alert('Bus route details added Successfull');</script>";
echo '<meta http-equiv="refresh" content="0;url=view.php">';
}
?>