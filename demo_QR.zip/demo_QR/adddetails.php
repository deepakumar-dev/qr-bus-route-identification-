<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Public bus  </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<!--<div id="header" style="background-color:#2e8080;-->
<?php
include('topnav.php');
?>

<div 
style="background-color:#41b0ab;
  background-position: center;
  background-size: cover;
  overflow: hidden;
  width:1550px;
  height:590px;z-index: -5;">
<?php include("topnavadmin.php")
?>
<?php
include('libs/phpqrcode/qrlib.php'); 
function getUsernameFromEmail($email) {
	$find = '@';
	$pos = strpos($email, $find); 
	$username = substr($email, 0, $pos);   
	return $username;
}
if(isset($_POST['submit']) ) {
	$tempDir = 'temp/'; 
	$email = $_POST['mail'];
	$from =  $_POST['from'];
	$to =  $_POST['to'];
	$filename = getUsernameFromEmail($email);
	$body =  $_POST['msg'];
	$codeContents = 'mailto:' . urlencode($email) . "\r\nfrom:" . urlencode($from) . "\r\nto:" . urlencode($to) . "\r\nDEATILS ABOUT BUS:" . urlencode($body);


	QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
}
?>
<!DOCTYPE html>
<html>
	<head>
	<link rel="stylesheet" href="libs/css/bootstrap.min.css">
	<link rel="stylesheet" href="libs/style.css">
    </head>
	<body><div class="input-field" style="color:black;margin-left:150px;">
				<h2>Add Bus Details</h2>
				
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
					<div class="form-group">
						<label>Bus Email</label>
						<input type="email" class="form-control" name="mail" style="width:20em;" placeholder="Enter your Email" value="<?php echo @$email; ?>" required />
					</div>
					<div class="form-group">
						<label>From</label>
						<input type="text" class="form-control" name="from" style="width:20em;" placeholder="Enter From" value="<?php echo @$from; ?>" required pattern="[a-zA-Z .]+" />
					</div>
					<div class="form-group">
						<label>To</label>
						<input type="text" class="form-control" name="to" style="width:20em;" placeholder="Enter To" value="<?php echo @$to; ?>" required pattern="[a-zA-Z .]+" />
					</div>
					
					<div class="form-group">
						<label>DEATILS ABOUT BUS</label>
						<textarea rows="5" cols="30" type="text" class="form-control" name="msg" style="width:20em;" value="<?php echo @$body; ?>" required pattern="[a-zA-Z0-9 .]+" placeholder="Enter your message"></textarea>
					</div>
					
					<div class="form-group">
						<input type="submit" name="submit" class="btn btn-danger submitBtn" style="width:20em; margin:0;" />
					</div>
				</form>
			</div>
		
<?php
			if(!isset($filename)){
				$filename = "qrshop";
			}
			?>
			<div class="qr-field" style="color:black;margin-right:380px;">
				<h2>QR Code Result: </h2>
				<center>
					<div class="qrframe" style="border:2px solid black; width:210px; height:210px;">
							<?php echo '<img src="temp/'. @$filename.'.png" style="width:200px; height:200px;"><br>'; ?>
					</div>
					<a class="btn btn-default submitBtn" style="width:210px; margin:5px;" href="download.php?file=<?php echo $filename; ?>.png " echo download="successfully">Download QR Code</a>
				<div><br><br><br>
		
			</center>
			</div>
	</div>	
	<div id="topbar" style="width:100%;background-color:black;height:50PX">
<p style="color:white;text-align:right"> &copy  <b>| Designed by </b></p>
</div>
	</body>

</html>