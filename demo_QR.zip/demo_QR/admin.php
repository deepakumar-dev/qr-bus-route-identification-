<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<!--<meta http-equiv="content-type" content="text/html; charset=utf-8" />-->
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<style>
                .centered-form {
            text-align: center;
        }

        .centered-form form {
            display: inline-block;
            text-align: left;
        }
    </style>
<body>
<?php
include('topnav.php');
?>
<div id="header" style="background-image: url('images/bus.gif');
  background-position: center;
  background-size: cover;
  overflow: hidden;
  width:1550px;
  height:580px;z-index: -5;">
<?php
include('navbar.php');
?><CENTER>
<div class="centered-form" style="margin-top:80px;width:300px;height:300px;border:2px solid yellow;background-color:#02a69e;">
<h1>Admin Login</h1>
        <form method="post" role="form">
            <div>
                <label for="name"></label><input type="text" name="username" class="form-control" id="name" placeholder="User Name" required>
            <br>
            <div>
                <label for="password"></label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
            </div>
            <br>
            <div>
                <center><input type="submit" class="btn btn-defeault btn-send" name="login" value="LOGIN"></center>
            </div></div>
        </form>
    
<!--<div class="container"> Wrap the form inside the container 
    <div class="row justify-content-center">  Use 'justify-content-center' to center the row
        <form method="post" role="form" class="bi-form">
            <div class="col-lg-4">
                <div class="form-group">
                    <span><label style="margin-left:100px;>Username :</label></span>
                    <input type="text" name="username" class="form-control" id="name" placeholder="Your Name" required>
                </div>
            </div>
            <br><br><br>
            <div class="col-lg-4">
                <div class="form-group">
                   
                    <span><label>Password : </label></span>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Your Password" required>
                </div>
            </div>
            <br><br>
            <div class="mt-0">
                <input type="submit" class="btn btn-defeault btn-send" name="login" value="LOGIN">
            </div>
        </form>
    </div>-->
</div>
</CENTER></div>
<?php
include('footer.php');
?>
</body>
<?php
if(isset($_POST['login']))
{
    $username=mysql_real_escape_string($_POST['username']);
	$password=mysql_real_escape_string($_POST['password']);
	$login_qry="SELECT * FROM admin WHERE username='$username' and password='$password'";
	$result=mysql_query($login_qry)or die("cant access");
	$count=mysql_num_rows($result);
	if($count>0){
	//header("location:booking.php");
	$n=mysql_fetch_array($result);
	$_SESSION['id']=$n['id'];
	
	echo "<script type='text/javascript'>alert('Admin Logged in successful');</script>";
	
	echo '<meta http-equiv="refresh" content="0;url=adddetails.php">';
	
	}
	else{
	echo "<script type='text/javascript'>alert('Admin account username or  password incorrect!');</script>";
		}
		
}

?>
</html>
