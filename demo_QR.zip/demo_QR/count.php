<?php
error_reporting(0);

// Include the necessary files and initialize your database connection here.
include "config.php"; // You can remove this line if it's not needed.
include 'include/db.php'; // You should include your database configuration here.

// Initialize the $imageCount and $userCount variables with default values.
$imageCount = 0;
$userCount = 0;

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $host = 'localhost';
    $mysql_username = 'root';
    $mysql_password = '';
    $mysql_db = 'qrcodes';

    // Create a MySQLi connection
    $conn = new mysqli($host, $mysql_username, $mysql_password, $mysql_db);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $qimg = $_FILES['pimg']['name'];

    // Insert the image into the 'insertqr' table
    $query = "INSERT INTO insertqr (qimg) VALUES ('$qimg')";
    if ($conn->query($query) === TRUE) {
        move_uploaded_file($_FILES['pimg']['tmp_name'], "upload/$qimg");
        echo "<script type='text/javascript'>alert('QR code added successfully');</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}

// After performing the insertion, let's update the $imageCount
$host = 'localhost';
$mysql_username = 'root';
$mysql_password = '';
$mysql_db = 'qrcodes';

// Create a MySQLi connection
$conn = new mysqli($host, $mysql_username, $mysql_password, $mysql_db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the total count of 'qimg' column
$imageQuery = "SELECT COUNT(qimg) AS img_count FROM insertqr";
$imageResult = $conn->query($imageQuery);

if ($imageResult) {
    $row = $imageResult->fetch_assoc();
    $imageCount = $row['img_count'];
} else {
    echo "Error: " . $conn->error;
}

// Query to get the total count of users
$userQuery = "SELECT COUNT(username) AS user_count FROM userregister";
$userResult = $conn->query($userQuery);

if ($userResult) {
    $row = $userResult->fetch_assoc();
    $userCount = $row['user_count'];
} else {
    echo "Error: " . $conn->error;
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>

<head>
    <title>BUS ROUTES FOR PUBLIC</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<?php
include('topnav.php');
?>

<div style="background-color:#41b0ab;
            background-position: center;
            background-size: cover;
            overflow: hidden;
            width:1030px;
            height:700px;z-index: -5;">
    <?php include("topnavadmin.php") ?>
    <center>
        <H3> Total count of QR Codes: <?php echo $imageCount; ?></H3>
        <H3> Total count of Users: <?php echo $userCount; ?></H3>
    </center>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<canvas id="pieChart" width="400" height="400"></canvas>
<script>
// Get the canvas element and create a chart context
var canvas = document.getElementById('pieChart');
var ctx = canvas.getContext('2d');

// Define data for the pie chart
var data = {
    labels: ['QR Codes', 'Users'],
    datasets: [{
        data: [<?php echo $imageCount; ?>, <?php echo $userCount; ?>],
        backgroundColor: ['#e09bd1', '#FFCE56'], // Define colors for the segments
    }],
};

// Create the pie chart
var pieChart = new Chart(ctx, {
    type: 'pie',
    data: data,
    options: {
        responsive: false, // Disable responsiveness to use fixed dimensions
        maintainAspectRatio: false, // Disable aspect ratio maintenance
    },
});
</script>
</div>
</html>
</body>
