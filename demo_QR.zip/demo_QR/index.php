<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<?php
include('topnav.php');
?><!--style="background-image: url('imgaes/bus.gif');"-->
<div id="header" style="background-image: url('images/bus.gif');
  width:1550px;
  height:600px;
  background-size:cover;">
<?php
include('navbar.php');
?>
<div>
  <h2 style="margin-left: 650px;margin-top:300px;color:#046e19;"><b>WELCOME to OUR BUS</b></h2>
</div>
</div>

<?php
include('footer.php');
?>
</body>

</html>
