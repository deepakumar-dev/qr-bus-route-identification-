<div id="topbar">
<marquee style="background-color:#02a69e">
<h3 style="color:black;background-size:cover;"><i>QR CODE SCAN BASED PUBLIC BUS ROUTE IDENTIFICATION FOR SEAMLESS COMMUNITY SYSTEM</i></h3>
</marquee></div> 
