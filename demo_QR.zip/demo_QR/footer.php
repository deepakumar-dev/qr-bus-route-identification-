<div id="topbar" style="width:100%;background-color:#02a69e;height:50PX">
<p style="color:black;text-align:right"> &copy  <b>| Designed by  </b></p>
</div>
