<?php
error_reporting(0);
include('include/db.php');
?> 
 <!DOCTYPE html>
<head>
<title> Public bus  </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div id="topbar"><center>
<marquee width="70%" direction="left" height="180px">
<h3 style="color:black;">BUS ROUTE MANAGEMENT SYSTEM FOR PUBLIC</h3>
</marquee>
</center>
</div><br><br>
<div id="container">
<div id="header">
 <nav class="navbar navbar-expand-lg bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="admin.php">Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="user.php">User registraion</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ulogin.php">user login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled">about us</a>
            </li>
          </ul>
        </div>
      </div>
	  <br><br><br><br><br><br>
	     <center>
		 <img src="images/down.png" height="300px" width="350px" STYLE="background-color:lightgreen">
			<div class="col-lg-6">
			<table>
			<tr><br><br><br><br>
			<td> 
              <form method="post"  role="form" class="bi-form">
                <div class="row gy-3">
                  <div class="col-lg-6">
                    <div class="form-group contact-block1">
					<center><i><h3>USER LOGIN</h3></i></center>
						<br><br>	
						<span><label>USER  NAME :</label></span>
						<input type="text" name="email" class="form-control" id="name" placeholder="Mail Id" required >
                    </div>
                  </div><br><br>
                  <div class="col-lg-6">
                    <div class="form-group">
										<span><label>PASSWORD :</label></span>
										<input type="password" class="form-control" name="password" id="password" placeholder="Your Password" required>
                    </div>
                  </div>
                
                <br><br>
                  <center><div class="mt-0">
                    <input type="submit" class="btn btn-defeault btn-send" name="submit" value="LOGIN">
</div></center>
                </div>
              </form>
			  </td>
			  </tr>
			  </table>
            </div>
			</center>
    </nav><br><br><br><br><br>
              </div>
            </div>
           </div>
        </div>
      </div>
    </div>
	 <div id="footer">
<p> &copy 2023 | Designed by  </p>
</div>
	 <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	
	<?php
if(isset($_POST['submit']))
{
$email=$_POST['email'];
$password=$_POST['password'];
$q=mysql_query("select * from userregister where email='$email' and password='$password'")or die(mysql_error());
$n=mysql_num_rows($q);
if($n>0)
{
$r=mysql_fetch_array($q);
$_SESSION['id']=$id=$r['id'];
$_SESSION['email']=$email=$r['email'];
echo '<meta http-equiv="refresh" content="0;url=viewqr.php">';
echo "<script type='text/javascript'>alert('successfully login');</script>";
}

else
{
echo "<script type='text/javascript'>alert('You are not authorised user');</script>";
}

}
?> 
</body>

</html>