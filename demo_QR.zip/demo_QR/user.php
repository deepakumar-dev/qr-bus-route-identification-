<?php
error_reporting(0);
include('include/db.php');
?> 
 <!DOCTYPE html>
<head>
<title> Public bus  </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div id="topbar"><center>
<marquee width="70%" direction="left" height="180px">
<h3 style="color:black;">BUS ROUTE MANAGEMENT SYSTEM FOR PUBLIC</h3>
</marquee>
</center>
</div><br><br>
<div id="container">

<div id="header">

<img src="images/user.png"/>
 <nav class="navbar navbar-expand-lg bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="admin.php">Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="user.php">User registraion</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ulogin.php">user login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled">about us</a>
            </li>
          </ul>
        </div>
      </div>
    </nav><br><br><br><br><br>

<!-- End Header -->

  <!-- ======= Contact Section ======= -->
    <div id="" class="paddsection">
      <div class="container">
        <div class="contact-block1">
          <div class="row">
          <div class="col-md-6" style="margin: 0 auto;">	
             <center> <form action=""  method="post" role="" class="bi-form">
                <div class="row gy-3">
                  <div class="col-lg-6">
					<div class="form-group contact-block1">
					<img src="images/55.jpg" height="450px" width="350px" STYLE="background-color:lightgreen">
<br><br><br><br>
					<span><label style="margin-right:11px">USER  NAME :</label></span>
                    <input type="text" name="username" style="margin-right:10px" class="form-control" id="name" placeholder=" @Enter username" required >
                    </div>
                  </div><br><br>
				  <div class="col-lg-6">
                    <div class="form-group">
                       <span><label style="margin-right:11px">MOBILE NO : </label></span>
                      <input type="number" class="form-control" style="margin-right:9px" name="mobileno" id="email" placeholder=" @Enter Mobile no"  maxlength="10" required >
                    </div>
                  </div><br><br>
				  <div class="col-lg-6">
                    <div class="form-group">
                       <span><label style="margin-right:11px">PASSWORD : </label></span>
                      <input type="text" class="form-control" style="margin-right:11px" name="password" id="email" placeholder="@Enter Password" required >
                    </div>
                  </div><br><br>
				  <div class="col-lg-6">
                    <div class="form-group">
					<span><label style="margin-right:11px">ADDRESS : </label></span>
                      <input type="address" class="form-control" style="margin-right:1px" name="address" id="email" placeholder="@Enter City" required >
                    </div>
                  </div><br><br>
				  <div class="col-lg-6">
                    <div class="form-group">				
					<span><label style="margin-right:11px">E --  MAIL : </label></span>
                      <input type="email" class="form-control" style="margin-right:-5px" name="email" id="email" placeholder=" @Enter Email" required >
                    </div>
                  </div><br><br><br>
				  <div class="col-lg-6">
                    <div class="form-group">		
					<span><label style="margin-right:11px">DISTRICT : </label></span>
                      <input type="text" class="form-control" style="margin-right: 5px" name="district" id="email" placeholder="@Enter District" required >
                    </div>
                  </div>
                <br><br>
                  <div class="mt-0">
                    <input type="submit" class="btn btn-defeault btn-send" style="margin-right:10px" name="Submit" value="SUBMIT"> 
				</div><br>
                </div>
              </form>		 </center> 
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Contact Section --><br><br>
	
	
	 <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <div id="footer">
<ul>
<!--<li><a href="#">Part Time Job</a></li>-->
</ul>
<p> &copy 2023 | Designed by  </p>
</div>
  </body>
	</html>
	
  
  <?php
if(isset($_POST['Submit']))
{
    $username=mysql_real_escape_string($_POST['username']);
	$mobileno=mysql_real_escape_string($_POST['mobileno']);
	$district=mysql_real_escape_string($_POST['district']);
	$address=mysql_real_escape_string($_POST['address']);
	$email=mysql_real_escape_string($_POST['email']);
	$password=mysql_real_escape_string($_POST['password']);
	
	
mysql_query("insert into userregister(username,  mobileno, district, address, email, password)
						values('$username', '$mobileno', '$district', '$address', '$email', '$password')")or die(mysql_error());
//move_uploaded_file($_FILES['pimg']['tmp_name'],"upload/$pimage");
echo "<script type='text/javascript'>alert('User details registered successfully !!!');</script>";
echo '<meta http-equiv="refresh" content="0;url=ulogin.php">';

		
}

?>