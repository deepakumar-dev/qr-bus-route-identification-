<?php
error_reporting(0);

// Include the necessary files and initialize your database connection here.
include "config.php"; // You can remove this line if it's not needed.
include 'include/db.php'; // You should include your database configuration here.

// Initialize the $imageCount variable with a default value.
$imageCount = 0;

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $host = 'localhost';
    $mysql_username = 'root';
    $mysql_password = '';
    $mysql_db = 'qrcodes';

    // Create a MySQLi connection
    $conn = new mysqli($host, $mysql_username, $mysql_password, $mysql_db);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $qimg = $_FILES['pimg']['name'];

    // Insert the image into the 'insertqr' table
    $query = "INSERT INTO insertqr (qimg) VALUES ('$qimg')";
    if ($conn->query($query) === TRUE) {
        move_uploaded_file($_FILES['pimg']['tmp_name'], "upload/$qimg");
        echo "<script type='text/javascript'>alert('QR code added successfully');</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}

// After performing the insertion, let's update the $imageCount
$host = 'localhost';
$mysql_username = 'root';
$mysql_password = '';
$mysql_db = 'qrcodes';

// Create a MySQLi connection
$conn = new mysqli($host, $mysql_username, $mysql_password, $mysql_db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the total count of 'qimg' column
$query = "SELECT COUNT(qimg) AS img_count FROM insertqr";
$result = $conn->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $imageCount = $row['img_count'];
} else {
    echo "Error: " . $conn->error;
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>BUS ROUTES FOR PUBLIC</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<?php
include('topnav.php');
?>
<div style="background-color:#41b0ab;
            background-position: center;
            background-size: cover;
            overflow: hidden;
            width:1550px;
            height:580px;z-index: -5;">
    <?php include("topnavadmin.php") ?>
    <center>
        <form method="POST" action="" name="adddetails" enctype="multipart/form-data">
            <br><h3>Upload a File</h3><br>
            <div style="background-color: lightgrey;
                width: 600px;
                border: 2px solid #e3cc86;
                padding: 100px;
                margin: 20px;
                box-shadow: 5px 10px #f0dc78;">
                <h3><input type="file" name="pimg" class="textbox"></h3>	<br><br>
                <button style="background-color:#27e346;">
                <input type="submit" name="submit" value="submit" style="background-color:#27e346;color:black;"></button><br>
              <!--  <h6>Total count of qimg column: <?php echo $imageCount; ?></h6>-->
              </div>
        </form>
    </center>
    <div id="topbar" style="width:100%;background-color:black;height:50PX">
<p style="color:white;text-align:right"> &copy  <b>| Designed by </b></p>
</div>
</div>
</html>
</body>
