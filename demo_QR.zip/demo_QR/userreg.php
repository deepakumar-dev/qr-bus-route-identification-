<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<!--<meta http-equiv="content-type" content="text/html; charset=utf-8" />-->
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<style>
                .centered-form {
            text-align: center;
        }

        .centered-form form {
            display: inline-block;
            text-align: left;
        }
    </style>
<body>
<?php
include('topnav.php');
?>
<div id="header" style="background-image: url('images/bus.gif');
  background-position: center;
  background-size: cover;
  overflow: hidden;
  width:1550px;
  height:580px;z-index: -5;">
<?php
include('navbar.php');
?><CENTER>

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="centered-form" style="margin-top:80px;width:800px;height:500px;border:2px solid yellow;background-color:#02a69e;">
  <h1>User Registration</h1>
      <h3>
      <form action="" method="post" role="" class="bi-form">
    <div style="display: flex; justify-content: space-between;">
        <!-- Left Column -->
        <div style="width: 45%; margin-right: 20px;">
            <div>
                <label for="username"></label>
                <input type="text" name="username" class="form-control" id="username" placeholder="Enter username" required>
            </div>
            <div>
                <label for="mobileno"></label>
                <input type="text" class="form-control" name="mobileno" id="mobileno" placeholder="Enter Mobile no" maxlength="10" required>
            </div>
            <div>
                <label for="password"></label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password" required>
            </div>
        </div>

        <!-- Right Column -->
        <div style="width: 45%; margin-left: 20px;">
            <div>
                <label for="address"></label>
                <input type="address" class="form-control" name="address" id="address" placeholder="Enter City" required>
            </div>
            <div>
                <label for="email"></label>
                <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required>
            </div>
            <div>
                <label for="district"></label>
                <input type="text" class="form-control" name="district" id="district" placeholder="Enter District" required>
            </div>
        </div>
    </div>

    <br><br>
    <input type="submit" class="btn-get-started scrollto" style="color: black; 
    background-color: #ed5a9f; margin-left: 150px" name="Submit" value="SUBMIT">
</form>

  </section><!-- End Hero --> </h3>

</div>
  
  <?php
if(isset($_POST['Submit']))
{
    $username=mysql_real_escape_string($_POST['username']);
	$mobileno=mysql_real_escape_string($_POST['mobileno']);
	$district=mysql_real_escape_string($_POST['district']);
	$address=mysql_real_escape_string($_POST['address']);
	$email=mysql_real_escape_string($_POST['email']);
	$password=mysql_real_escape_string($_POST['password']);
	
	
mysql_query("insert into userregister(username,  mobileno, district, address, email, password)
						values('$username', '$mobileno', '$district', '$address', '$email', '$password')")or die(mysql_error());
echo "<script type='text/javascript'>alert('User details registered successfully !!!');</script>";
echo '<meta http-equiv="refresh" content="0;url=userlog.php">';

		
}

?>


</body>
</html>