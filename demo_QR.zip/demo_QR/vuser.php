<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div id="topbar"><center>
<marquee width="70%" direction="left" height="180px">
<h3 style="color:black;">BUS ROUTE MANAGEMENT SYSTEM FOR PUBLIC</h3>
</marquee>
</center>
</div><br><br>
<div id="container">

<div id="header">

<!--img src="upload/download.png"/>-->
 <nav class="navbar navbar-expand-lg bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="adddetails.php">admin side</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
		  <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="adddetails.php">add details</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="vuser.php">vuser</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="inserqr.php">Insert qrcode</a>
            </li>
			<li class="nav-item">
              <a class="nav-link active" aria-current="page" href="vuser.php">vuser</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
           
          </ul>
        </div>
      </div>
    </nav>

</div>

	
			
	</body>

</html>