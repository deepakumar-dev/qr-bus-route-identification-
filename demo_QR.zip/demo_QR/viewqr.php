<?php
error_reporting(0);
include "config.php";
include('include/db.php');
?>
<!DOCTYPE html>
<head>
<title> Public bus  </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
<?php
include('topnav.php');
?><!--style="background-image: url('imgaes/bus.gif');"-->

<div id="header" style="background-color:#41b0ab;
  width:1520px;
  height:600px;
  background-size:cover;">
<?php
include('navuser.php');
?>
<div>
<nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNav">
     
			<div class="container" style="margin-left:30px;">
  <div class="row row-cols-5 row-cols-md-3 g-4">
    <?php
    $t = mysql_query("SELECT * FROM insertqr");
    while ($w = mysql_fetch_array($t)) {
      $id = $w['id'];
      $qimg = $w['qimg'];
    ?>
      <div class="col">
        <div class="card" style="width:200px;">
          <?php echo $id ?>
          <img src="temp\<?php echo $qimg; ?>" class="img"><br>
          <div class="card-body"><center>
            <h5 class="card-title"><b>SCAN NOW</b></h5></hr>
            <p class="card-text">FIND THE DETAILS ABOUT THIS BUS</p></center>
          </div>
        </div>
      </div>
    <?php
    }
    ?>
  </div>
</div></div>

      </div></div></div>
	  	
</body></div></div></div>
<?php
include('footer.php');
?>

</html>
